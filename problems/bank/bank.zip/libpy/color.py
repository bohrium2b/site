from termcolor import cprint


def print_red(text: str) -> None:
    cprint(text, color="red")

def print_green(text: str) -> None:
    cprint(text, color="green")


def print_yellow(text: str) -> None:
    cprint(text, color="yellow")
