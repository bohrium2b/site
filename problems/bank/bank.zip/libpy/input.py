def get_string(prompt: str) -> str:
    # Prompts a user for a string
    string = input(prompt)
    while not string:
        string = input(prompt)
    return string


def get_int(prompt: str) -> int:
    # Prompts a user for an integer
    integer = get_string(prompt)
    converted = False
    while not converted:
        try:
            integer = int(integer)
            converted = True
        except Exception:
            integer = get_string(prompt)
            converted = False
    return integer