"""
This program manages a user's money by keeping track of deposits and withdrawals.
"""

from libpy.libpy import *


def main():
    # Instructions
    print("This program manages your money")
    print("Enter each deposit and withdrawal")
    print("To indicate a withdrawal, use a minus sign")
    print("Signal the end by entering a 0")
    # Prompt user for initial balance

    # Start keeping track of deposits and withdrawals
    # while TRUE:
    #     # TODO


# Run main() when the program is run
if __name__ == "__main__":
    # This should always be true
    main()
